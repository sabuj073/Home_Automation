package com.example.user.smarthomeautomation;

import android.content.Intent;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.widget.Button;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {


    boolean found = false;

    private final String DEVICE_ADDRESS = "98:D3:51:F5:A6:89"; //MAC Address of Bluetooth Module
    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    private BluetoothDevice device;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    Button bluetooth_connect_btn;


    String command, data,value;   //save the command

    ImageView light_info, fan_info;
    Switch aSwitch,bSwitch;

    String light_toast = "On\nCommand : Light On\nOff\nCommand : Light off.";
    String fan_toast = "On\nCommand : Fan on\nOff\nCommand : Fan off.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        light_info = findViewById(R.id.info1);
        fan_info = findViewById(R.id.info2);
        bluetooth_connect_btn = findViewById(R.id.bluetooth_connect_btn);
        aSwitch = findViewById(R.id.switch1);
        bSwitch = findViewById(R.id.switch2);


        light_info.setOnClickListener(new View.OnClickListener() {    //Toast
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, light_toast, Toast.LENGTH_LONG).show();
            }
        });

        fan_info.setOnClickListener(new View.OnClickListener() {   //Toast
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, fan_toast, Toast.LENGTH_LONG).show();
            }
        });


        //light switch
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(aSwitch.isChecked())
                {
                    value = "1";
                    try {
                        if (found) {
                            outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
                else {
                    value = "2";
                    try {
                        if (found) {
                            outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
        });


        bSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(bSwitch.isChecked())
                {
                    value = "3";
                    try {
                        if (found) {
                            outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                else
                {
                    value = "4";
                    try {
                        if (found) {
                            outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
        });


        //Button that connects the device to the bluetooth module when pressed
        bluetooth_connect_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (BTinit()) {
                    BTconnect();
                }

            }
        });


    }

    public void getSpeechInput(View view) {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    command = result.get(0);
                    Toast.makeText(MainActivity.this, command, Toast.LENGTH_SHORT).show();
                    if (!command.isEmpty()) {
                        if (command.equals("light on")) {
                            value = "1";
                            try {
                                if (found) {
                                    outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                                    aSwitch.setChecked(true);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else if (command.equals("light off")) {
                            value = "2";
                            try {
                                if (found) {
                                    outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                                    aSwitch.setChecked(false);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else if (command.equals("fan on")) {
                            value = "3";
                            try {
                                if (found) {
                                    outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                                    bSwitch.setChecked(true);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else if (command.equals("fan off")) {
                            value = "4";
                            try {
                                if (found) {
                                    outputStream.write(value.getBytes()); //transmits the value of command to the bluetooth module
                                    bSwitch.setChecked(false);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }
                break;
        }
    }


    //Initializes bluetooth module
    public boolean BTinit() {

        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) //Checks if the device supports bluetooth
        {
            Toast.makeText(getApplicationContext(), "Device doesn't support bluetooth", Toast.LENGTH_SHORT).show();
        }

        if (!bluetoothAdapter.isEnabled()) //Checks if bluetooth is enabled. If not, the program will ask permission from the user to enable it
        {
            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableAdapter, 0);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();

        if (bondedDevices.isEmpty()) //Checks for paired bluetooth devices
        {
            Toast.makeText(getApplicationContext(), "Please pair the device first", Toast.LENGTH_SHORT).show();
        } else {
            for (BluetoothDevice iterator : bondedDevices) {
                if (iterator.getAddress().equals(DEVICE_ADDRESS)) {
                    device = iterator;
                    found = true;
                    break;
                }
            }
        }

        return found;
    }

    public boolean BTconnect() {
        boolean connected = true;

        try {
            socket = device.createRfcommSocketToServiceRecord(PORT_UUID); //Creates a socket to handle the outgoing connection
            socket.connect();

            Toast.makeText(getApplicationContext(),
                    "Connection to bluetooth device successful", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            connected = false;
        }

        if (connected) {
            try {
                outputStream = socket.getOutputStream(); //gets the output stream of the socket
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return connected;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

}
